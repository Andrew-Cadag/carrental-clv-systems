# ai/app.py
# Flask API for CLV Prediction
# Serves the trained Random Forest model via HTTP endpoints

from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np

# Initialize Flask application
app = Flask(__name__)

# Enable CORS to allow requests from the backend (localhost:8000)
CORS(app, origins=['http://localhost:8000'])

# Load the pre-trained model on startup
# This model was created by train.py and predicts CLV tiers (Low, Medium, High)
print("Loading CLV model...")
try:
    with open('clv_model.pkl', 'rb') as f:
        model = pickle.load(f)
    print("Model loaded successfully!")
except FileNotFoundError:
    print("Error: clv_model.pkl not found. Please run train.py first.")
    model = None


@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict Customer Lifetime Value tier based on RFM metrics.
    
    Expected JSON body:
    {
        "frequency": int,      # Number of purchases/interactions
        "total_spent": float,  # Total monetary value
        "recency": int         # Months since last interaction
    }
    
    Returns:
    {
        "clv": "High" | "Medium" | "Low"
    }
    """
    # Check if model is available
    if model is None:
        return jsonify({'error': 'Model not loaded. Please train the model first.'}), 500
    
    # Get JSON data from request body
    data = request.get_json()
    
    # Validate required fields are present
    required_fields = ['frequency', 'total_spent', 'recency']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    try:
        # Extract features from request
        frequency = int(data['frequency'])
        total_spent = float(data['total_spent'])
        recency = int(data['recency'])
        
        # Prepare feature vector for prediction
        # Must match the order used during training: [frequency, total_spent, recency]
        features = np.array([[frequency, total_spent, recency]])
        
        # Make prediction using the loaded model
        prediction = model.predict(features)[0]
        
        # Return the CLV tier as a JSON response
        return jsonify({'clv': prediction})
        
    except (ValueError, TypeError) as e:
        # Handle invalid data types (e.g., strings where numbers expected)
        return jsonify({'error': f'Invalid data type: {str(e)}'}), 400


@app.route('/health', methods=['GET'])
def health_check():
    """
    Health check endpoint to verify the service is running.
    Returns model status and a success message.
    """
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None
    })


if __name__ == '__main__':
    # Run the Flask application on port 5000
    # This matches the FLASK_URL configured in the backend .env
    print("Starting CLV Prediction API on http://localhost:5000")
    print("Available endpoints:")
    print("  POST /predict - Get CLV prediction")
    print("  GET /health   - Health check")
    app.run(host='0.0.0.0', port=5000, debug=True)
