# ai/train.py
# CLV Prediction Model Training Script
# Trains a Random Forest classifier to predict Customer Lifetime Value tiers

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import pickle

# Load the dataset from CSV file
print("Loading dataset...")
df = pd.read_csv('WA_Fn-UseC_-Marketing-Customer-Value-Analysis.csv')

# Select only the columns needed for CLV prediction
# These columns represent: purchase frequency, total value, and recency
columns_to_use = ['Number of Policies', 'Customer Lifetime Value', 'Months Since Last Claim']
df = df[columns_to_use]

# Remove any rows with missing values to ensure clean data
print(f"Dataset shape before cleaning: {df.shape}")
df = df.dropna()
print(f"Dataset shape after cleaning: {df.shape}")

# Rename columns for clarity and consistency with business terminology
df = df.rename(columns={
    'Number of Policies': 'frequency',        # How many policies customer has = frequency
    'Customer Lifetime Value': 'total_spent',   # CLV value = total spending
    'Months Since Last Claim': 'recency'       # Time since last interaction = recency
})

# Create the target variable (CLV tier) using quantile-based discretization
# This divides customers into 3 equal groups: Low (bottom 33%), Medium (middle 33%), High (top 33%)
print("Creating CLV labels...")
df['clv_label'] = pd.qcut(df['total_spent'], q=3, labels=['Low', 'Medium', 'High'])

# Prepare features (X) and target (y) for model training
# Features: RFM-style metrics (frequency, total_spent, recency)
X = df[['frequency', 'total_spent', 'recency']]
y = df['clv_label']

print(f"Feature matrix shape: {X.shape}")
print(f"Target distribution:\n{y.value_counts()}")

# Split data into training (80%) and testing (20%) sets
# random_state ensures reproducibility
print("Splitting data into train/test sets...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Initialize Random Forest classifier
# n_estimators=100 means 100 trees in the forest
# random_state ensures reproducible results
print("Training Random Forest model...")
model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model on the training data
model.fit(X_train, y_train)

# Evaluate model performance on test set
print("Evaluating model...")
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")

# Save the trained model to disk using pickle
# This allows the Flask API to load and use the model for predictions
print("Saving model to clv_model.pkl...")
with open('clv_model.pkl', 'wb') as f:
    pickle.dump(model, f)

print("Training complete! Model saved as clv_model.pkl")
