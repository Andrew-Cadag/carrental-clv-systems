const express = require('express');
const router = express.Router();
const messageController = require('../controllers/message.controller');
const verifyToken = require('../middleware/verifyToken');

router.get('/conversations', verifyToken, messageController.getConversations);
router.get('/bookings', verifyToken, messageController.getBookingsForMessaging);
router.get('/unread-counts', verifyToken, messageController.getUnreadCounts);
router.get('/:booking_id', verifyToken, messageController.getMessagesByBooking);
router.post('/', verifyToken, messageController.sendMessage);

module.exports = router;
