const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const verifyToken = require('../middleware/verifyToken');
const checkRole = require('../middleware/checkRole');

router.get('/me', verifyToken, userController.getMyProfile);
router.put('/me', verifyToken, userController.updateMyProfile);
router.put('/me/password', verifyToken, userController.changePassword);
router.get('/', verifyToken, checkRole('admin', 'staff'), userController.getAllUsers);
router.get('/:id', verifyToken, checkRole('admin', 'staff'), userController.getUserById);
router.put('/:id', verifyToken, checkRole('admin'), userController.updateUser);
router.delete('/:id', verifyToken, checkRole('admin'), userController.deleteUser);

module.exports = router;
