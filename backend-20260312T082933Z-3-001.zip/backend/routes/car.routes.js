const express = require('express');
const router = express.Router();
const carController = require('../controllers/car.controller');
const verifyToken = require('../middleware/verifyToken');
const checkRole = require('../middleware/checkRole');

router.get('/', carController.getAllCars);
router.get('/browse', verifyToken, carController.getAllCarsWithAvailability);
router.get('/:id', carController.getCarById);
router.post('/', verifyToken, checkRole('admin'), carController.createCar);
router.put('/:id', verifyToken, checkRole('admin'), carController.updateCar);
router.delete('/:id', verifyToken, checkRole('admin'), carController.deleteCar);

module.exports = router;
