const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/booking.controller');
const verifyToken = require('../middleware/verifyToken');
const checkRole = require('../middleware/checkRole');

router.get('/', verifyToken, checkRole('admin', 'staff'), bookingController.getAllBookings);
router.get('/my-bookings', verifyToken, bookingController.getMyBookings);
router.get('/car/:car_id/booked-dates', verifyToken, bookingController.getBookedDatesForCar);
router.get('/:id', verifyToken, bookingController.getBookingById);
router.post('/', verifyToken, bookingController.createBooking);
router.put('/:id', verifyToken, bookingController.updateBooking);
router.put('/:id/status', verifyToken, checkRole('admin', 'staff'), bookingController.updateBookingStatus);
router.delete('/:id', verifyToken, bookingController.cancelBooking);

module.exports = router;
