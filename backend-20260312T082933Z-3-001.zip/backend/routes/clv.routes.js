const express = require('express');
const router = express.Router();
const clvController = require('../controllers/clv.controller');
const verifyToken = require('../middleware/verifyToken');
const checkRole = require('../middleware/checkRole');

router.get('/', verifyToken, checkRole('admin'), clvController.getAllCLVScores);
router.get('/:user_id/history', verifyToken, clvController.getCLVHistory);
router.post('/predict/:user_id', verifyToken, checkRole('admin'), clvController.predictCLV);

module.exports = router;
